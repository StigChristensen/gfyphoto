<?php
/**
 * The template for displaying the footer
 */
?>

	</div><!-- .site-content -->

	<footer id="colophon" class="site-footer" role="contentinfo">

  </footer>

</div>

<?php wp_footer(); ?>


</body>
</html>
